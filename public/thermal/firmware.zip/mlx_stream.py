# MLX90640 (32x24 サーマル, I2C addr 0x33) -> USBシリアルへ生データストリーム
# 配線: VIN->3V3(36), GND->38, SDA->GP4(6), SCL->GP5(7)
#       ※VL53L5CX と同一バス相乗り(アドレスが 0x29 / 0x33 で別なので共存可)
#
# 設計方針: Pico は「土管」。温度への較正計算(EEPROM展開+To計算)は
# ブラウザ側 thermal-viewer.html の JS が行う(RP2040 の純Pythonでは遅すぎるため)。
#
# 行プロトコル(1行=1メッセージ, 16進4桁を空白区切り):
#   EE <832 words>   EEPROM 0x2400..0x273F。起動時+以後20フレーム毎に再送
#                    (ブラウザが後から接続しても較正パラメータを拾えるように)
#   FR <834 words>   RAM 0x0400..0x073F(832) + 制御レジスタ0x800D + サブページ番号
#                    = Melexis MLX90640_GetFrameData と同じ並び
#   # ...            情報コメント / ERR ... 異常(出力して継続)
import sys
import time
import struct
from machine import I2C, Pin

ADDR = 0x33
EE_RESEND_EVERY = 20   # フレーム毎のEEPROM再送間隔
CHUNK = 128            # I2C連続リードの分割単位(ワード)

# timeout=500ms: 実機教訓(2026-07-11)。machine.I2C既定50msは長い転送で切れることがある
# (duoのToF fw転送で実際に発生)。MLX単体の転送は短く必須ではないが、余裕を揃えて取る。
i2c = I2C(0, scl=Pin(5), sda=Pin(4), freq=400_000, timeout=500_000)


def rd_words(reg, n):
    """regからnワードを連続リード(ビッグエンディアン, CHUNKワードずつ)"""
    out = []
    while n:
        c = CHUNK if n > CHUNK else n
        data = i2c.readfrom_mem(ADDR, reg, c * 2, addrsize=16)
        out.extend(struct.unpack(">%dH" % c, data))
        reg += c
        n -= c
    return out


def wr_word(reg, val):
    i2c.writeto_mem(ADDR, reg, struct.pack(">H", val & 0xFFFF), addrsize=16)


def emit(tag, words):
    sys.stdout.write(tag + " " + " ".join("%04x" % w for w in words) + "\n")


def setup_control():
    """制御レジスタ0x800D: リフレッシュ4Hz(0b011) + チェスパターン。他ビットは温存"""
    ctrl = rd_words(0x800D, 1)[0]
    ctrl = (ctrl & 0xFC7F) | (0b011 << 7)   # bits9:7 = refresh rate (adafruit setterと同じマスク)
    ctrl |= 0x1000                           # bit12 = chess pattern
    wr_word(0x800D, ctrl)
    return rd_words(0x800D, 1)[0]


def get_frame():
    """Melexis MLX90640_GetFrameData 相当: 834ワードを返す"""
    # new-data bit (status 0x8000 bit3) を待つ
    st = rd_words(0x8000, 1)[0]
    while not (st & 0x0008):
        time.sleep_ms(10)
        st = rd_words(0x8000, 1)[0]
    # クリア(0x0030)→RAM読み。読んでいる間に次データが来たら読み直し(最大5回)
    cnt = 0
    fr = None
    while (st & 0x0008) and cnt < 5:
        wr_word(0x8000, 0x0030)
        fr = rd_words(0x0400, 832)
        st = rd_words(0x8000, 1)[0]
        cnt += 1
    if cnt > 4:
        raise OSError("too many frame retries")
    ctrl = rd_words(0x800D, 1)[0]
    fr.append(ctrl)
    fr.append(st & 0x0001)   # 直前に測定されたサブページ番号
    return fr


def main():
    # ---- 初期化(センサ未接続でも ERR を出しつつ粘る) ----
    while True:
        try:
            devs = i2c.scan()
            if ADDR not in devs:
                print("ERR 0x33 not on I2C bus (scan: %s)" % [hex(d) for d in devs])
                time.sleep_ms(1000)
                continue
            ctrl = setup_control()
            print("# mlx90640 ctrl=0x%04x (4Hz, chess)" % ctrl)
            ee = rd_words(0x2400, 832)
            emit("EE", ee)
            break
        except Exception as e:
            print("ERR init: %s" % e)
            time.sleep_ms(1000)

    nframe = 0
    while True:
        try:
            fr = get_frame()
            emit("FR", fr)
            nframe += 1
            if nframe % EE_RESEND_EVERY == 0:
                emit("EE", ee)
        except Exception as e:
            print("ERR frame: %s" % e)
            time.sleep_ms(500)


main()
