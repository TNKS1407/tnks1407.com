MLX90640 サーマルストリーム firmware
=====================================
対象: Raspberry Pi Pico / Pico 2 / Pico W (素のMicroPython)

配線 (3.3V厳守。5V/VBUS直結は禁止):
  VIN -> 3V3(物理36) / GND -> 38 / SDA -> GP4(物理6) / SCL -> GP5(物理7)

起動:
  pip install mpremote
  python -m mpremote connect COMx run mlx_stream.py
  COM番号はデバイスマネージャの「ポート(COM と LPT)」か
  python -m mpremote connect list で確認(抜き差しで変わることがある)。

I2C timeout=500ms の理由:
  machine.I2C の既定タイムアウト(50ms)は、長いI2Cトランザクションで
  OSError: ETIMEDOUT を出すことがある(同シリーズのToFファーム転送で実際に発生)。
  MLX単体の転送(128語ずつ≒数ms)では必須ではないが、余裕を10倍取ってある。

その他:
  - シリアルは1プロセス占有。mpremote runをCtrl+Cで止めてからビューアで「接続」。
    (runを止めてもスクリプトはPico上で走り続ける)
  - 常用は cp mlx_stream.py :main.py -> USBを挿すだけで流れる。戻すは rm :main.py。
  - 温度較正はブラウザ側JS(Adafruit MITドライバの移植)。FWは生データの土管に徹する。
  - 電源投入から数分は自己発熱で絵がドリフトする。
