# ToF(VL53L5CX 0x29) × サーマル(MLX90640 0x33) 相乗りストリーム — 1本のFWで両方読む
# 配線: 両センサとも 3V3(36)/GND(38)/SDA GP4(6)/SCL GP5(7) 並列。ToFのLPn=GP6(9)
# 依存: :lib/vl53l5cx/ (firmware/DEPLOY.md の手順で導入済みのドライバをそのままimport)
#
# 行プロトコル(混流。ビューア duo-viewer.html が行種で振り分ける):
#   <64個のmm整数カンマ区切り>  ToF 8x8 (無効=-1)      … 既存 tof_stream.py と同形式
#   EE <832 hex>                MLX EEPROM (起動時+20フレーム毎に再送)
#   FR <834 hex>                MLX フレーム (RAM832 + 制御レジスタ + サブページ)
#   # ...                       情報 / ERR ... 異常(出力して継続)
#
# ---- バス速度の根拠 (400kHzで開始) ----
# ・MLX90640 データシート(I2C節): FM+対応、SCL最大1MHz (I2C設定レジスタ0x800FにFM+関連ビット)
# ・VL53L5CX データシート(I2C節): fast mode plus、最大1MHz
#   → 両者とも仕様上は1MHz共通で行ける。ただし2ボードのプルアップが並列で立ち上がりは
#   速くなる方向とはいえ、配線長・ノイズ余裕をみて保守的に400kHzから始める。
# ・400kHz ≈ 44kB/s 実効。MLX 1フレーム≈1.7kB→約38ms、4Hzでデューティ~15%。
#   ToF 8x8(距離+状態のみ)は結果バッファ数百B→数ms、15Hzで~10%。合計<30%で足りる。
#   ToF読み出しがMLXの38ms読みと重なった時だけ最大~半フレーム待ち
#   → ToF実効 ~13-14fps の見込み(未実測)。足りなければ両データシートの範囲内で1MHzへ。
# ・USBシリアルは合計~13kB/s。PicoのUSB CDCはbaud値が名目(実効はUSB速度)なので問題ない。
import sys
import time
import struct
from machine import I2C, Pin

I2C_FREQ = 400_000    # RP2040(Pico W)実機の教訓(2026-07-11): 1MHzはRP2040のI2Cが不安定(書き込み化け疑い)。
I2C_TIMEOUT_US = 500_000  # machine.I2C既定50msだとToF fw転送のチャンク書き込みがETIMEDOUT→要延長
MLX_ADDR = 0x33
TOF_ADDR = 0x29
EE_RESEND_EVERY = 20   # MLXフレーム毎のEEPROM再送間隔
CHUNK = 128            # MLX連続リードの分割単位(ワード)

i2c = I2C(0, scl=Pin(5), sda=Pin(4), freq=I2C_FREQ, timeout=I2C_TIMEOUT_US)


# ================= MLX90640 側 (thermal/firmware/mlx_stream.py と同一ロジック) =================
def mlx_rd_words(reg, n):
    out = []
    while n:
        c = CHUNK if n > CHUNK else n
        data = i2c.readfrom_mem(MLX_ADDR, reg, c * 2, addrsize=16)
        out.extend(struct.unpack(">%dH" % c, data))
        reg += c
        n -= c
    return out


def mlx_wr_word(reg, val):
    i2c.writeto_mem(MLX_ADDR, reg, struct.pack(">H", val & 0xFFFF), addrsize=16)


def emit(tag, words):
    sys.stdout.write(tag + " " + " ".join("%04x" % w for w in words) + "\n")


def mlx_setup():
    """制御レジスタ0x800D: リフレッシュ4Hz + チェスパターン。EEPROMを返す"""
    ctrl = mlx_rd_words(0x800D, 1)[0]
    ctrl = (ctrl & 0xFC7F) | (0b011 << 7)   # bits9:7 = refresh 4Hz
    ctrl |= 0x1000                           # bit12 = chess
    mlx_wr_word(0x800D, ctrl)
    print("# mlx90640 ctrl=0x%04x (4Hz, chess)" % mlx_rd_words(0x800D, 1)[0])
    return mlx_rd_words(0x2400, 832)


def mlx_poll_frame():
    """データ未着ならNone。着いていればMelexis GetFrameData相当の834語(ノンブロッキング)"""
    st = mlx_rd_words(0x8000, 1)[0]
    if not (st & 0x0008):
        return None
    cnt = 0
    fr = None
    while (st & 0x0008) and cnt < 5:
        mlx_wr_word(0x8000, 0x0030)
        fr = mlx_rd_words(0x0400, 832)
        st = mlx_rd_words(0x8000, 1)[0]
        cnt += 1
    if cnt > 4:
        raise OSError("mlx too many frame retries")
    fr.append(mlx_rd_words(0x800D, 1)[0])
    fr.append(st & 0x0001)
    return fr


# ================= VL53L5CX 側 (firmware/tof_stream.py と同一ロジック) =================
def tof_setup():
    """初期化(ファーム転送で~5秒)。(tof, 有効status集合)を返す"""
    from vl53l5cx.mp import VL53L5CXMP
    from vl53l5cx import DATA_DISTANCE_MM, DATA_TARGET_STATUS, RESOLUTION_8X8
    tof = VL53L5CXMP(i2c, lpn=Pin(6, Pin.OUT, value=1))
    print("# tof init...(firmware upload ~5s)")
    tof.reset()
    tof.init()
    tof.resolution = RESOLUTION_8X8
    tof.ranging_freq = 15
    tof.start_ranging({DATA_DISTANCE_MM, DATA_TARGET_STATUS})
    print("# tof streaming 8x8 @15Hz")
    return tof


def tof_emit(tof):
    r = tof.get_ranging_data()
    d = r.distance_mm
    s = r.target_status
    out = []
    for i in range(64):
        ok = s[i] in (5, 9)          # STATUS_VALID / STATUS_VALID_LARGE_PULSE
        out.append(str(d[i]) if ok else "-1")
    sys.stdout.write(",".join(out) + "\n")


# ================= 起動 =================
def main():
    devs = i2c.scan()
    print("# i2c scan: %s" % [hex(d) for d in devs])

    # --- MLX: 速いので先に上げてEEを早く流す(片方欠けても他方は動かす) ---
    mlx_ok = False
    ee = None
    if MLX_ADDR in devs:
        try:
            ee = mlx_setup()
            emit("EE", ee)
            mlx_ok = True
        except Exception as e:
            print("ERR mlx init: %s" % e)
    else:
        print("ERR mlx 0x33 not found (thermal disabled)")

    # --- ToF: ファーム転送~5秒。その間MLXフレームは流れない(センサ内で更新されるだけ) ---
    tof = None
    if TOF_ADDR in devs:
        try:
            tof = tof_setup()
        except Exception as e:
            print("ERR tof init: %s" % e)
            tof = None
    else:
        print("ERR tof 0x29 not found (depth disabled)")

    if not mlx_ok and tof is None:
        print("ERR no sensors — check wiring, rebooting loop")

    # --- ループ: 届いたものから流す。片方の例外で他方を殺さない ---
    nframe = 0
    while True:
        did = False
        if tof is not None:
            try:
                if tof.check_data_ready():
                    tof_emit(tof)
                    did = True
            except Exception as e:
                print("ERR tof: %s" % e)
                time.sleep_ms(200)
        if mlx_ok:
            try:
                fr = mlx_poll_frame()
                if fr is not None:
                    emit("FR", fr)
                    did = True
                    nframe += 1
                    if nframe % EE_RESEND_EVERY == 0:
                        emit("EE", ee)
            except Exception as e:
                print("ERR mlx: %s" % e)
                time.sleep_ms(200)
        if not did:
            time.sleep_ms(2)


main()
