ToF(VL53L5CX) × サーマル(MLX90640) 相乗り firmware
====================================================
内容:
  duo_stream.py        本体(1本で両センサを読み、1本のシリアルへ混流)。実機検証済み版
  vl53l5cx/            MicroPythonドライバ (MIT License, (c)2021 Mark Grosen)
                       ファイル内のcopyright表記はそのまま残してある

配線 (3.3V厳守):
  3V3(36)/GND(38)/SDA GP4(6)/SCL GP5(7) を両センサ並列 + ToFのLPn -> GP6(9)
  ※ToFの給電線は太く短く直結。細いジャンパの継ぎ足しは電圧降下で
    初期化に失敗する(実測0.5V降下の前科)。

配置(ドライバをPicoの :lib/vl53l5cx へ):
  python -m mpremote connect COMx mkdir :lib
  python -m mpremote connect COMx mkdir :lib/vl53l5cx
  python -m mpremote connect COMx cp vl53l5cx/__init__.py :lib/vl53l5cx/__init__.py
  python -m mpremote connect COMx cp vl53l5cx/_config_file.py :lib/vl53l5cx/_config_file.py
  python -m mpremote connect COMx cp vl53l5cx/mp.py :lib/vl53l5cx/mp.py
  python -m mpremote connect COMx cp vl53l5cx/vl_fw_config.bin :lib/vl53l5cx/vl_fw_config.bin

起動:
  python -m mpremote connect COMx run duo_stream.py
  (ToF初期化はファーム転送で約5秒。COM番号はデバイスマネージャ/mpremote connect list)

I2C 400kHz + timeout=500ms (実機の教訓 2026-07-11):
  - 1MHzはRP2040(Pico W)実機でI2Cが不安定だった(書き込み化け疑い) -> 400kHzで運用。
  - machine.I2C既定のtimeout 50msだと、ToFファーム転送のチャンク書き込みが
    OSError: ETIMEDOUT で切れる -> 500msに延長してある。

ビューア:
  /duo/ のほか、単独ビューア(/tof/, /thermal/)も同じストリームに接続できる。
  シリアルは1プロセス占有 -> mpremoteを止めてからブラウザで接続。
