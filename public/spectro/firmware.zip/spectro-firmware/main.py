# AS7341 (11ch 分光センサ, I2C addr 0x39) -> USBシリアルへ JSON行ストリーム
# 配線: VIN->3V3(36番pin), GND->38番pin, SDA->GP4(6番pin), SCL->GP5(7番pin)
#
# 設計方針: Pico は薄いドライバ。SMUX を2バンク切替(F1-F4 / F5-F8)して
# 10ch(F1..F8 + Clear + NIR)を読み、1行JSONで送る。表示・履歴はブラウザ側。
# レジスタ運びは Adafruit の2ドライバに準拠(ref/ に取得済みソースあり):
#   - Adafruit_CircuitPython_AS7341 (MIT)   ... adafruit_as7341.py
#   - Adafruit_AS7341 (Arduino)             ... Adafruit_AS7341.cpp
# SMUXの20バイト表は両ドライバで一致することを突合済み。
#
# 行プロトコル(1行=1メッセージ):
#   {"t":<ms>,"ch":[f1..f8,clear,nir],"gain":<x>,"itime":<ms>,"sat":0|1}
#   # ...   情報コメント
#   ERR ... 異常(出力して継続)
# ※ "sat" は追加フィールド(アナログ飽和ASAT or デジタル飽和)。ビューアは無くても動く。

import time
import struct
from machine import I2C, Pin

ADDR = 0x39

# ---- レジスタ (Adafruit両ドライバと突合済み) ----
R_ENABLE  = 0x80   # bit0 PON / bit1 SP_EN / bit4 SMUXEN(完了で自己クリア)
R_ATIME   = 0x81
R_ID      = 0x92   # bits7:2 = 0b001001 -> (val & 0xFC) == 0x24
R_ASTATUS = 0x94   # ここから13バイト: ASTATUS + CH0..CH5(LE)。読み出しでラッチ(DS §10.2.7)
R_STATUS2 = 0xA3   # bit6 = AVALID
R_CFG1    = 0xAA   # AGAIN: 0..10 -> x0.5..x512 (gain = 2^(n-1))
R_CFG6    = 0xAF   # SMUX_CMD: 0x10 = RAMからSMUX設定を書き込むモード
R_ASTEP_L = 0xCA   # 16bit LE (0xCA/0xCB)

# ---- 既定値 ----
ATIME = 17          # 積分 = (ATIME+1)*(ASTEP+1)*2.78us = 18*1000*2.78us = 50.04ms
ASTEP = 999
ITIME_MS = (ATIME + 1) * (ASTEP + 1) * 2.78 / 1000.0
FULLSCALE = min(65535, (ATIME + 1) * (ASTEP + 1))   # = 18000 counts
GAIN_IDX = 7        # x64 スタート
AUTOGAIN = True     # 飽和寄りで1段下げ / 小さすぎたら1段上げ(しきい値は自作、根拠は下記)

# SMUX 20バイト(レジスタ0x00..0x13へ書く)。上位ニブル/下位ニブルで2画素ずつADCへ接続。
# 出典: Adafruit_AS7341.cpp setup_F1F4_Clear_NIR / setup_F5F8_Clear_NIR
# F1F4バンク: ADC0=F1 ADC1=F2 ADC2=F3 ADC3=F4 ADC4=Clear ADC5=NIR
SMUX_F1F4 = bytes((0x30, 0x01, 0x00, 0x00, 0x00, 0x42, 0x00, 0x00, 0x50, 0x00,
                   0x00, 0x00, 0x20, 0x04, 0x00, 0x30, 0x01, 0x50, 0x00, 0x06))
# F5F8バンク: ADC0=F5 ADC1=F6 ADC2=F7 ADC3=F8 ADC4=Clear ADC5=NIR
SMUX_F5F8 = bytes((0x00, 0x00, 0x00, 0x40, 0x02, 0x00, 0x10, 0x03, 0x50, 0x10,
                   0x03, 0x00, 0x00, 0x00, 0x24, 0x00, 0x00, 0x50, 0x00, 0x06))

# 400kHz + timeout は RP2040 の既知の癖への対処(1MHzは不安定になることがある)
# VERIFY: timeout キーワードは MicroPython のバージョン依存。古い版で
#         TypeError になったら timeout=500_000 を外して使う。
i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=400_000, timeout=500_000)


def rd8(reg):
    return i2c.readfrom_mem(ADDR, reg, 1)[0]


def wr8(reg, val):
    i2c.writeto_mem(ADDR, reg, bytes((val & 0xFF,)))


def fmt_gain(idx):
    return "0.5" if idx == 0 else str(1 << (idx - 1))


def sp_en(on):
    en = rd8(R_ENABLE)
    wr8(R_ENABLE, (en | 0x02) if on else (en & 0xFD))


def smux_load(table):
    """SMUX設定をRAM経由で流し込む (Adafruit: setSMUXLowChannels 相当)。
    手順: SP_EN off -> CFG6=0x10 -> 0x00..0x13へ20バイト -> SMUXEN -> 自己クリア待ち"""
    sp_en(False)
    wr8(R_CFG6, 0x10)
    for i in range(20):
        wr8(i, table[i])   # ドライバ同様1バイトずつ(バースト書きは実機未確認なので使わない)
    wr8(R_ENABLE, rd8(R_ENABLE) | 0x10)   # SMUXEN
    t0 = time.ticks_ms()
    while rd8(R_ENABLE) & 0x10:           # 完了で自己クリア(Arduino版は1000msでタイムアウト)
        if time.ticks_diff(time.ticks_ms(), t0) > 1000:
            raise OSError("SMUX timeout")
        time.sleep_ms(1)


def read_bank(table):
    """1バンク測定: SMUX切替 -> SP_EN -> AVALID待ち -> ASTATUS+CH0..CH5 (13バイト)"""
    smux_load(table)
    sp_en(True)                           # ここから新しい積分が走る
    t0 = time.ticks_ms()
    while not (rd8(R_STATUS2) & 0x40):    # AVALID
        if time.ticks_diff(time.ticks_ms(), t0) > int(ITIME_MS) + 1000:
            raise OSError("AVALID timeout")
        time.sleep_ms(2)
    buf = i2c.readfrom_mem(ADDR, R_ASTATUS, 13)   # ASTATUS読みで6ch分がラッチされる
    astat = buf[0]                                # bit7 = ASAT_STATUS(アナログ飽和)
    ch = struct.unpack_from("<6H", buf, 1)
    return astat, ch


def setup():
    devs = i2c.scan()
    if ADDR not in devs:
        raise OSError("0x39 not on I2C bus (scan: %s)" % [hex(d) for d in devs])
    chip = rd8(R_ID)
    if (chip & 0xFC) != 0x24:             # bits7:2 == 0b001001 (Adafruit両ドライバと同じ判定)
        raise OSError("unexpected ID reg 0x92=0x%02x" % chip)
    wr8(R_ENABLE, 0x01)                   # PON のみ(他ビットは0で初期化)
    time.sleep_ms(1)
    wr8(R_ATIME, ATIME)
    i2c.writeto_mem(ADDR, R_ASTEP_L, struct.pack("<H", ASTEP))
    wr8(R_CFG1, GAIN_IDX)
    print("# as7341 ok: atime=%d astep=%d itime=%.2fms fullscale=%d gain=x%s"
          % (ATIME, ASTEP, ITIME_MS, FULLSCALE, fmt_gain(GAIN_IDX)))


def main():
    global GAIN_IDX
    # ---- 初期化(センサ未接続でも ERR を出しつつ粘る) ----
    while True:
        try:
            setup()
            break
        except Exception as e:
            print("ERR init: %s" % e)
            time.sleep_ms(1000)

    errs = 0
    while True:
        try:
            a1, low = read_bank(SMUX_F1F4)     # F1..F4 + Clear + NIR
            a2, high = read_bank(SMUX_F5F8)    # F5..F8 + Clear + NIR
            # Clear/NIR は両バンクで測れるが、後で測った F5F8 側を採用(前バンク分は捨てる)
            ch = list(low[0:4]) + list(high[0:4]) + [high[4], high[5]]
            mx = max(ch)
            sat = 1 if ((a1 | a2) & 0x80) or mx >= FULLSCALE else 0
            print('{"t":%d,"ch":[%s],"gain":%s,"itime":%.2f,"sat":%d}' % (
                time.ticks_ms(), ",".join(str(v) for v in ch),
                fmt_gain(GAIN_IDX), ITIME_MS, sat))
            errs = 0
            # ---- 簡易オートゲイン ----
            # しきい値(>90%で下げ / <5%で上げ)は自作の設計値。ゲイン段が2倍刻みなので
            # 5%*2=10% < 90% となり往復発振はしない、という理屈。実機で要確認。
            if AUTOGAIN:
                if (sat or mx > FULLSCALE * 9 // 10) and GAIN_IDX > 0:
                    GAIN_IDX -= 1
                    wr8(R_CFG1, GAIN_IDX)
                    print("# autogain: down -> x%s" % fmt_gain(GAIN_IDX))
                elif mx < FULLSCALE // 20 and GAIN_IDX < 10:
                    GAIN_IDX += 1
                    wr8(R_CFG1, GAIN_IDX)
                    print("# autogain: up -> x%s" % fmt_gain(GAIN_IDX))
        except Exception as e:
            print("ERR frame: %s" % e)
            time.sleep_ms(500)
            errs += 1
            if errs >= 5:                  # 抜き差し等でセンサが初期化を失った場合に備える
                errs = 0
                try:
                    setup()
                except Exception as e2:
                    print("ERR reinit: %s" % e2)


main()
