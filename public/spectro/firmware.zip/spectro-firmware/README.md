# spectro — AS7341 11ch 分光ビューア

お家でセンサ遊び第3弾。AS7341（11ch分光センサ, I2C addr 0x39）＋ Pico を
ブラウザ（Web Serial）で覗く。thermal（MLX90640）と同じ型：
Picoは薄いドライバでJSON行を吐き、表示・履歴・スケーリングは全部ブラウザ側。

## ファイル

- `index.html` … ビューア（単一HTML・外部CDNなし・日本語UI）
- `firmware/main.py` … Pico用MicroPython（Picoに `main.py` として保存）
- `ref/` … レジスタ運びの突合に使った Adafruit ドライバ（CircuitPython版 + Arduino版）
- `VERIFY.md` … **未検証事項リスト（実機前に必読）**
- `.shots/` … 開発時のヘッドレスEdgeスクショと390px幅テストharness

## 配線（I2C0, 3.3V給電）

| AS7341ボード | Pico | 物理ピン |
|---|---|---|
| VIN (3.3V) | 3V3(OUT) | 36 |
| GND | GND | 38 |
| SDA | GP4 | 6 |
| SCL | GP5 | 7 |

- バスは 400kHz + timeout 指定（RP2040の癖。1MHzは不安定になることがある）。
- VL53L5CX(0x29) / MLX90640(0x33) と同一バス相乗り可（0x39 なのでアドレス衝突なし）。
- プルアップは市販ブレークアウト搭載のものを想定。**5V給電はしない**（3.3V）。

## 使い方

1. `firmware/main.py` を Pico に `main.py` として書き込む（Thonny か `mpremote cp firmware/main.py :main.py`）。
2. `index.html` を Chrome/Edge で開く（file:// でOK）。
3. 「Picoに接続」→ ポート選択（115200）。
4. 実機がなくても「デモ」3プリセットで全機能が触れる：
   - **太陽光** … 連続スペクトル。雲の切れ間でClearが飽和⚠に触れる仕込み
   - **白色LED** … 445nmの青ピーク＋蛍光体の土手
   - **葉っぱ** … 緑ピーク＋NIRが跳ね上がるレッドエッジ
   - URLでも指定可: `?demo=sun` / `?demo=led` / `?demo=leaf`

## 行プロトコル（115200, 1行=1メッセージ）

```
{"t":<ms>,"ch":[f1,f2,f3,f4,f5,f6,f7,f8,clear,nir],"gain":<x>,"itime":<ms>,"sat":0|1}
# ...   情報コメント
ERR ... 異常（出力して継続）
```

- `ch` は生カウント（F1..F8 = 415/445/480/515/555/590/630/680nm、Clear=広帯域可視、NIR≈910nm※通説値）。
- `gain` は倍率そのもの（0.5〜512）。`itime` は積分時間[ms]。
- `sat` は仕様外の追加フィールド（アナログ飽和ASAT または デジタル飽和）。無くてもビューアは動く。
- Clear/NIR は2バンクとも測っているが、後で測る F5F8 バンク側を採用（設計判断、VERIFY.md参照）。

## ファームウェア既定値

| 項目 | 値 | 意味 |
|---|---|---|
| ATIME / ASTEP | 17 / 999 | 積分 = 18×1000×2.78µs = **50.04ms** |
| フルスケール | 18000 counts | (ATIME+1)×(ASTEP+1)、65535で頭打ち |
| 初期ゲイン | x64 (AGAIN=7) | |
| オートゲイン | 有効 | 最大chが>90%FSで1段↓ / <5%FSで1段↑（x0.5〜x512） |

レート目安: 2バンク × (50ms + SMUX切替) ≈ 数Hz（実測は未、VERIFY.md）。

## ビューアの小ワザ

- 棒にホバー/タップで値の読み出し。ClearとNIRは広帯域なので**別枠・別スケール**。
- 「正規化 counts/(gain·ms)」… オートゲインで生カウントが段差を作っても連続して見える。
- 時系列はチップでチャネル選択（可視8chは共通スケール、Clear/NIRは自前スケール）。
- 開発フック: `?dbg=1`（レイアウト寸法表示）/ `?dbg=2`（対数+正規化+NIR選択で起動）。

## 出典

レジスタ運び・SMUX設定は Adafruit の2ドライバに準拠（`ref/` に取得済み、20バイト表は両者一致を突合済み）:
- [Adafruit_CircuitPython_AS7341](https://github.com/adafruit/Adafruit_CircuitPython_AS7341) (MIT)
- [Adafruit_AS7341 (Arduino)](https://github.com/adafruit/Adafruit_AS7341) (BSD)
